import React, { Component } from 'react'
import Navbar from './Navbar'
import Register from './Register'

export default class RegisterPage extends Component {
    render() {
        return (
            <div>
                <Navbar/>
                <Register/>
            </div>
        )
    }
}


